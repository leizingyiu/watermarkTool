win
下载文件，解压

附件: watermark.zip  https://pan.baidu.com/s/1RgcuDMkzqtsmQ8kByrrEnw 提取码: k43k 


将要加水印的文件放到 [自己新建] 的pic文件夹
图片: https://uploader.shimo.im/f/XGbgizPwp1OBdDBA.png?sm_xform=image%2Fcrop%2Cx_0%2Cy_20%2Cw_267%2Ch_88&accessToken=eyJhbGciOiJIUzI1NiIsImtpZCI6ImRlZmF1bHQiLCJ0eXAiOiJKV1QifQ.eyJhdWQiOiJhY2Nlc3NfcmVzb3VyY2UiLCJleHAiOjE2MzY1MTQwNzgsImciOiJ2M0toeEpjdkR0UFBEaDZoIiwiaWF0IjoxNjM2NTEzNzc4LCJ1c2VySWQiOjM1ODIzNjN9.DxhW4zosPGVcWEVvCO5zXM1vlk2noAaUtz5w5lbPutU


双击watermark.exe


完成
图片: https://uploader.shimo.im/f/beBBaZWhtFg1JzFk.png?sm_xform=image%2Fcrop%2Cx_0%2Cy_20%2Cw_299%2Ch_632&accessToken=eyJhbGciOiJIUzI1NiIsImtpZCI6ImRlZmF1bHQiLCJ0eXAiOiJKV1QifQ.eyJhdWQiOiJhY2Nlc3NfcmVzb3VyY2UiLCJleHAiOjE2MzY1MTQwNzgsImciOiJ2M0toeEpjdkR0UFBEaDZoIiwiaWF0IjoxNjM2NTEzNzc4LCJ1c2VySWQiOjM1ODIzNjN9.DxhW4zosPGVcWEVvCO5zXM1vlk2noAaUtz5w5lbPutU

_________________


mac
python.org 下载python稳定版
python.org

使用pip安装Pillow
sudo pip3.x install Pillow -i https://pypi.douban.com/simple/


将需要添加水印的图片放到pic文件夹
将水印命名为watermark.png
在IDLE中打开py文件，按f5运行




